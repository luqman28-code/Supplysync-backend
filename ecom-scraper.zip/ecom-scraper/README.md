# Enterprise eCommerce Scraper

A production-grade Python scraper that extracts complete product data from any eCommerce website.

## Supported Platforms
- **Shopify** — via `/products.json` API (no auth required)
- **WooCommerce** — via WC REST API v3 + HTML fallback
- **Magento, PrestaShop, OpenCart** — via HTML + JSON-LD
- **Custom PHP stores** — generic HTML parser with heuristic selectors
- **WordPress** — HTML + JSON-LD + microdata

## Data Extracted

| Field | Description |
|---|---|
| Title, SKU, Barcode/GTIN/EAN | Core identifiers |
| Full HTML description | Complete product copy |
| Short description | Summary text |
| Price, Sale price, Currency | All price points |
| Brand / Vendor | Supplier info |
| Product type, Categories, Tags | Taxonomy |
| Variants (size/colour/etc.) | All variant combinations |
| Variant prices, SKUs, stock, images | Per-variant data |
| Image gallery + featured image | All product images |
| Videos | Embedded video URLs |
| Stock status + inventory qty | Availability |
| Weight + dimensions | Shipping attributes |
| Attributes + specifications | Spec tables, DL lists |
| SEO title + meta description | On-page SEO |
| Breadcrumbs + collections | Navigation context |
| Reviews + ratings | Customer feedback |
| Related products | Cross-sell URLs |
| Downloads / PDFs | Linked files |

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### Basic
```bash
python scraper.py --url https://example.com
```

### Shopify store (force platform, limit to 500 products)
```bash
python scraper.py --url https://mystore.myshopify.com --platform shopify --max-products 500
```

### WooCommerce with proxy
```bash
python scraper.py --url https://woosite.com --platform woocommerce --proxy http://user:pass@proxy:8080
```

### Custom store, JSON output only, faster
```bash
python scraper.py --url https://customstore.com --format json --workers 5 --delay 0.5
```

### Use proxy list + export all formats
```bash
python scraper.py --url https://example.com --proxy-list proxies.txt --format all
```

### Use sitemap directly
```bash
python scraper.py --url https://example.com --sitemap https://example.com/sitemap-products.xml
```

## Options

| Flag | Default | Description |
|---|---|---|
| `--url` | required | Target website |
| `--format` | `all` | `json` / `csv` / `excel` / `shopify_csv` / `all` |
| `--output` | `output/` | Output directory |
| `--max-products` | `0` (unlimited) | Stop after N products |
| `--workers` | `3` | Concurrent scraping workers |
| `--delay` | `1.0` | Seconds between requests |
| `--proxy` | — | Single proxy URL |
| `--proxy-list` | — | File with proxy URLs (one per line) |
| `--platform` | auto-detect | Force: `shopify` / `woocommerce` / `magento` / `custom` |
| `--sitemap` | auto-discover | Explicit sitemap URL |
| `--no-images` | off | Skip image extraction |
| `--no-reviews` | off | Skip review extraction |
| `--log-level` | `INFO` | `DEBUG` / `INFO` / `WARNING` / `ERROR` |

## Output Files

All outputs are saved to `output/` (or your `--output` directory):

- `products_TIMESTAMP.json` — Full structured data including all nested variants/reviews
- `products_TIMESTAMP.csv` — Flat CSV with all fields, variants as count
- `products_TIMESTAMP.xlsx` — Excel workbook with Products + Variants sheets
- `products_TIMESTAMP_shopify.csv` — Shopify import-ready CSV (one row per variant)
- `scraper_TIMESTAMP.log` — Full request log

## Shopify CSV Import

The `shopify_csv` format is directly importable via:
**Shopify Admin → Products → Import**

It follows the official Shopify CSV spec with:
- One row per variant
- Multiple image rows per product
- Correct Handle/Title structure
- Weights converted to grams
- Status set to `draft` by default

## Proxy List Format

One proxy per line:
```
http://user:pass@host1:8080
http://user:pass@host2:8080
socks5://user:pass@host3:1080
```

## Architecture

```
scraper.py              # CLI entry point
core/
  platform_detector.py  # Auto-detect Shopify/WooCommerce/etc.
  crawler.py            # URL discovery + concurrent scraping coordinator
  models.py             # Product + ProductVariant + ProductReview dataclasses
  scrapers/
    shopify.py          # Shopify JSON API scraper
    woocommerce.py      # WooCommerce REST API + HTML scraper
    generic.py          # Universal HTML scraper (JSON-LD, OG, microdata, CSS)
exporters/
  exporter.py           # JSON / CSV / Excel / Shopify CSV export
utils/
  requests.py           # Async HTTP, user-agent rotation, retry logic
  logger.py             # File + console logging
```

## Notes

- Respects `robots.txt` conventions via polite delays (configurable)
- Deduplicates products by SKU
- Handles lazy-loaded images via `data-src` / `data-lazy-src` attributes
- Auto-discovers sitemaps at common paths
- Falls back through multiple extraction strategies per product
