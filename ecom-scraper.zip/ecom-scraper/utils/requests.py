"""
Request utilities: rotating user agents, session management, retry logic.
"""

import asyncio
import random
import aiohttp
from typing import Optional, List


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
]

ACCEPT_HEADERS = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
]


def get_random_headers(referer: str = "") -> dict:
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": random.choice(ACCEPT_HEADERS),
        "Accept-Language": random.choice([
            "en-US,en;q=0.9",
            "en-GB,en;q=0.9",
            "en-US,en;q=0.8,es;q=0.5",
        ]),
        "Accept-Encoding": "gzip, deflate, br",
        "DNT": "1",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Cache-Control": "max-age=0",
    }
    if referer:
        headers["Referer"] = referer
    return headers


class RequestSession:
    def __init__(self, proxies: List[str] = None, delay: float = 1.0, logger=None):
        self.proxies = proxies or []
        self.delay = delay
        self.logger = logger
        self._session: Optional[aiohttp.ClientSession] = None
        self._last_request = 0.0

    async def __aenter__(self):
        connector = aiohttp.TCPConnector(ssl=False, limit=20)
        timeout = aiohttp.ClientTimeout(total=30, connect=10)
        self._session = aiohttp.ClientSession(connector=connector, timeout=timeout)
        return self

    async def __aexit__(self, *args):
        if self._session:
            await self._session.close()

    def _get_proxy(self) -> Optional[str]:
        if self.proxies:
            return random.choice(self.proxies)
        return None

    async def get(self, url: str, referer: str = "", retries: int = 3) -> Optional[str]:
        for attempt in range(retries):
            try:
                # Respect delay
                await asyncio.sleep(self.delay + random.uniform(0, 0.5))

                headers = get_random_headers(referer)
                proxy = self._get_proxy()

                async with self._session.get(
                    url,
                    headers=headers,
                    proxy=proxy,
                    allow_redirects=True,
                ) as resp:
                    if resp.status == 200:
                        return await resp.text(errors="replace")
                    elif resp.status == 429:
                        wait = (attempt + 1) * 5
                        if self.logger:
                            self.logger.warning(f"Rate limited on {url}, waiting {wait}s")
                        await asyncio.sleep(wait)
                    elif resp.status in (403, 401):
                        if self.logger:
                            self.logger.warning(f"Blocked ({resp.status}) on {url}")
                        await asyncio.sleep(3)
                    elif resp.status == 404:
                        return None
                    else:
                        if self.logger:
                            self.logger.debug(f"HTTP {resp.status} on {url}")
            except asyncio.TimeoutError:
                if self.logger:
                    self.logger.warning(f"Timeout on {url} (attempt {attempt+1}/{retries})")
                await asyncio.sleep(2 ** attempt)
            except Exception as e:
                if self.logger:
                    self.logger.warning(f"Error fetching {url}: {e} (attempt {attempt+1}/{retries})")
                await asyncio.sleep(2 ** attempt)

        return None

    async def get_json(self, url: str, retries: int = 3) -> Optional[dict]:
        import json
        for attempt in range(retries):
            try:
                await asyncio.sleep(self.delay * 0.5)
                headers = get_random_headers()
                headers["Accept"] = "application/json"
                proxy = self._get_proxy()

                async with self._session.get(url, headers=headers, proxy=proxy) as resp:
                    if resp.status == 200:
                        return await resp.json(content_type=None)
                    elif resp.status == 429:
                        await asyncio.sleep((attempt + 1) * 5)
                    elif resp.status == 404:
                        return None
            except Exception as e:
                if self.logger:
                    self.logger.debug(f"JSON fetch error {url}: {e}")
                await asyncio.sleep(2 ** attempt)
        return None
