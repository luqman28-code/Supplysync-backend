"""
Logger setup with file + console output.
"""

import logging
import sys
from pathlib import Path
from datetime import datetime


def setup_logger(level: str = "INFO", output_dir: str = "output") -> logging.Logger:
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    log_file = Path(output_dir) / f"scraper_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

    logger = logging.getLogger("ecom_scraper")
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))
    logger.handlers.clear()

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    # Console
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    # File
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    return logger
