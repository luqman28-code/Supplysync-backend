"""
Crawler - discovers product URLs via sitemap, API, and link crawling.
Coordinates platform-specific scrapers.
"""

import re
import asyncio
from typing import List, Set, Optional
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

from core.models import Product
from utils.requests import RequestSession
from core.scrapers.shopify import ShopifyScraper
from core.scrapers.woocommerce import WooCommerceScraper
from core.scrapers.generic import GenericScraper


# URL patterns that strongly suggest a product page
PRODUCT_URL_PATTERNS = [
    r"/products?/[^/?#]+",
    r"/item/[^/?#]+",
    r"/p/[^/?#]+",
    r"/shop/[^/?#]+/[^/?#]+",
    r"/catalogue/[^/?#]+",
    r"/store/[^/?#]+",
    r"[?&]product_id=\d+",
    r"[?&]p=\d+",
    r"/en/[^/?#]+-p\d+",
    r"/goods/[^/?#]+",
]

# URL patterns to skip
SKIP_URL_PATTERNS = [
    r"/cart", r"/checkout", r"/account", r"/login", r"/register",
    r"/search", r"/tag/", r"/author/", r"/wp-admin", r"/wp-login",
    r"\.(jpg|jpeg|png|gif|webp|svg|pdf|zip|css|js|xml)$",
    r"/page/\d+$",
]


def is_product_url(url: str) -> bool:
    path = urlparse(url).path.lower()
    query = urlparse(url).query
    full = path + ("?" + query if query else "")
    for pattern in SKIP_URL_PATTERNS:
        if re.search(pattern, full, re.I):
            return False
    for pattern in PRODUCT_URL_PATTERNS:
        if re.search(pattern, full, re.I):
            return True
    return False


def is_same_domain(url: str, base: str) -> bool:
    return urlparse(url).netloc == urlparse(base).netloc


class Crawler:
    def __init__(
        self,
        base_url: str,
        platform: str,
        workers: int = 3,
        delay: float = 1.0,
        proxies: List[str] = None,
        max_products: int = 0,
        skip_images: bool = False,
        skip_reviews: bool = False,
        sitemap_url: str = None,
        logger=None,
    ):
        self.base_url = base_url.rstrip("/")
        self.platform = platform
        self.workers = workers
        self.delay = delay
        self.proxies = proxies or []
        self.max_products = max_products
        self.skip_images = skip_images
        self.skip_reviews = skip_reviews
        self.sitemap_url = sitemap_url
        self.logger = logger

        self._visited: Set[str] = set()
        self._product_urls: List[str] = []
        self._products: List[Product] = []
        self._seen_skus: Set[str] = set()
        self._semaphore = asyncio.Semaphore(workers)

    def log(self, msg: str, level: str = "info"):
        if self.logger:
            getattr(self.logger, level)(msg)

    async def run(self) -> List[Product]:
        async with RequestSession(self.proxies, self.delay, self.logger) as session:
            self.session = session

            # Step 1: Discover product URLs
            self.log(f"Discovering product URLs for platform: {self.platform}")
            await self._discover_urls()
            self.log(f"Found {len(self._product_urls)} product URLs to scrape")

            if not self._product_urls:
                self.log("No product URLs found. Trying generic crawl...", "warning")
                await self._crawl_links()
                self.log(f"Generic crawl found {len(self._product_urls)} product URLs")

            # Apply max_products limit
            if self.max_products > 0:
                self._product_urls = self._product_urls[:self.max_products]
                self.log(f"Limiting to {self.max_products} products")

            # Step 2: Scrape each product
            self.log(f"Scraping {len(self._product_urls)} products with {self.workers} workers...")
            await self._scrape_all()

        return self._products

    async def _discover_urls(self):
        # Try sitemap first
        urls = await self._try_sitemaps()
        if urls:
            self._product_urls = list(dict.fromkeys(urls))  # dedupe, preserve order
            return

        # Platform-specific discovery
        if self.platform == "shopify":
            scraper = ShopifyScraper(self.base_url, self.session, self.logger)
            urls = await scraper.get_product_urls()
        elif self.platform == "woocommerce":
            scraper = WooCommerceScraper(self.base_url, self.session, self.logger)
            urls = await scraper.get_product_urls()
        else:
            urls = []

        if urls:
            self._product_urls = list(dict.fromkeys(urls))

    async def _try_sitemaps(self) -> List[str]:
        sitemap_urls = [
            self.sitemap_url,
            f"{self.base_url}/sitemap.xml",
            f"{self.base_url}/sitemap_index.xml",
            f"{self.base_url}/sitemap-products.xml",
            f"{self.base_url}/product-sitemap.xml",
        ]
        all_product_urls = []
        for sm_url in sitemap_urls:
            if not sm_url:
                continue
            html = await self.session.get(sm_url)
            if not html:
                continue
            urls = self._parse_sitemap(html, sm_url)
            all_product_urls.extend(urls)
            if urls:
                self.log(f"Sitemap {sm_url}: found {len(urls)} potential product URLs")

        # Filter to product-like URLs
        product_urls = [u for u in all_product_urls if is_product_url(u) or self._looks_like_product_page(u)]
        return product_urls

    def _parse_sitemap(self, xml: str, base: str) -> List[str]:
        urls = []
        soup = BeautifulSoup(xml, "xml")

        # Sitemap index - recursively load child sitemaps
        for sitemap in soup.find_all("sitemap"):
            loc = sitemap.find("loc")
            if loc:
                # We'll handle sub-sitemaps synchronously in discovery
                child_url = loc.get_text().strip()
                urls.append(("__sitemap__", child_url))  # Marker for sub-sitemap

        # Regular URLs
        for url_el in soup.find_all("url"):
            loc = url_el.find("loc")
            if loc:
                urls.append(loc.get_text().strip())

        # Flat list (some sitemaps just have <loc> tags)
        if not urls:
            for loc in soup.find_all("loc"):
                urls.append(loc.get_text().strip())

        return [u for u in urls if isinstance(u, str) and u.startswith("http")]

    def _looks_like_product_page(self, url: str) -> bool:
        path = urlparse(url).path
        parts = [p for p in path.split("/") if p]
        # Heuristic: 2-3 path segments, last is not a number-only string
        return 2 <= len(parts) <= 4 and not parts[-1].isdigit()

    async def _crawl_links(self, max_pages: int = 200):
        """Generic link crawler for platforms without APIs or sitemaps."""
        to_visit = [self.base_url]
        visited = set()
        product_urls = set()
        pages_crawled = 0

        while to_visit and pages_crawled < max_pages:
            url = to_visit.pop(0)
            if url in visited:
                continue
            visited.add(url)
            pages_crawled += 1

            html = await self.session.get(url, referer=self.base_url)
            if not html:
                continue

            soup = BeautifulSoup(html, "html.parser")
            for a in soup.find_all("a", href=True):
                href = a["href"]
                full = urljoin(url, href).split("#")[0].split("?")[0]
                if not is_same_domain(full, self.base_url):
                    continue
                if full in visited:
                    continue
                if is_product_url(full):
                    product_urls.add(full)
                elif not any(re.search(p, full, re.I) for p in SKIP_URL_PATTERNS):
                    to_visit.append(full)

            if pages_crawled % 10 == 0:
                self.log(f"Crawled {pages_crawled} pages, found {len(product_urls)} product URLs")

        self._product_urls = list(product_urls)

    async def _scrape_all(self):
        tasks = [self._scrape_one(url) for url in self._product_urls]
        await asyncio.gather(*tasks)

    async def _scrape_one(self, url: str):
        async with self._semaphore:
            try:
                product = await self._scrape_product(url)
                if product:
                    # Deduplication by SKU
                    dedup_key = product.sku or product.url
                    if dedup_key in self._seen_skus:
                        self.log(f"Skipping duplicate: {dedup_key}", "debug")
                        return
                    self._seen_skus.add(dedup_key)
                    self._products.append(product)
                    self.log(f"[{len(self._products)}] Scraped: {product.title[:60]}")
            except Exception as e:
                self.log(f"Error scraping {url}: {e}", "error")

    async def _scrape_product(self, url: str) -> Optional[Product]:
        if self.platform == "shopify":
            scraper = ShopifyScraper(self.base_url, self.session, self.logger)
            return await scraper.scrape_product(url)
        elif self.platform in ("woocommerce", "wordpress"):
            scraper = WooCommerceScraper(self.base_url, self.session, self.logger)
            return await scraper.scrape_product(url)
        else:
            scraper = GenericScraper(self.base_url, self.session, self.logger)
            return await scraper.scrape_product(url)
