"""
Platform Detector - Identifies eCommerce platform from HTTP headers, HTML, and JS globals.
"""

import re
import aiohttp
from urllib.parse import urlparse


PLATFORM_SIGNATURES = {
    "shopify": {
        "headers": ["x-shopid", "x-shopify-stage"],
        "html": [
            r'cdn\.shopify\.com',
            r'Shopify\.theme',
            r'"platform":"shopify"',
            r'myshopify\.com',
            r'ShopifyAnalytics',
        ],
        "meta": [],
    },
    "woocommerce": {
        "headers": [],
        "html": [
            r'woocommerce',
            r'WooCommerce',
            r'wc-cart',
            r'"woocommerce"',
            r'add-to-cart=\d+',
        ],
        "meta": [],
    },
    "magento": {
        "headers": ["x-magento-tags", "x-magento-cache-id"],
        "html": [
            r'Mage\.Cookies',
            r'magentostore',
            r'"Magento_',
            r'mage/cookies',
            r'data-mage-init',
        ],
        "meta": [],
    },
    "bigcommerce": {
        "headers": ["x-bc-storefront"],
        "html": [
            r'cdn\.bigcommerce\.com',
            r'BigCommerce',
            r'"platform":"bigcommerce"',
        ],
        "meta": [],
    },
    "prestashop": {
        "headers": [],
        "html": [
            r'PrestaShop',
            r'prestashop',
            r'id_product',
            r'add_to_cart',
        ],
        "meta": [],
    },
    "opencart": {
        "headers": [],
        "html": [
            r'OpenCart',
            r'route=product/product',
            r'opencart',
        ],
        "meta": [],
    },
}


class PlatformDetector:
    def __init__(self, url: str):
        self.url = url
        self.domain = urlparse(url).netloc

    async def detect(self) -> str:
        try:
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            async with aiohttp.ClientSession() as session:
                async with session.get(self.url, headers=headers, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    resp_headers = dict(resp.headers)
                    html = await resp.text(errors="replace")

            for platform, sigs in PLATFORM_SIGNATURES.items():
                # Check headers
                for h in sigs["headers"]:
                    if h.lower() in {k.lower(): v for k, v in resp_headers.items()}:
                        return platform
                # Check HTML patterns
                for pattern in sigs["html"]:
                    if re.search(pattern, html, re.IGNORECASE):
                        return platform

            # WordPress fallback (without WooCommerce = generic WordPress)
            if re.search(r'wp-content|wp-includes|wordpress', html, re.IGNORECASE):
                return "wordpress"

            return "custom"
        except Exception:
            return "custom"
