"""
WooCommerce scraper - uses WC REST API v3 + HTML fallback.
"""

import re
import json
from typing import List, Optional
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from core.models import Product, ProductVariant, ProductReview
from utils.requests import RequestSession


class WooCommerceScraper:
    def __init__(self, base_url: str, session: RequestSession, logger=None):
        self.base_url = base_url.rstrip("/")
        self.session = session
        self.logger = logger

    async def get_product_urls(self) -> List[str]:
        """Try WC REST API first, then sitemap, then crawl."""
        urls = await self._api_product_urls()
        if urls:
            return urls
        return []  # Crawler will handle via HTML

    async def _api_product_urls(self) -> List[str]:
        urls = []
        page = 1
        while True:
            api_url = f"{self.base_url}/wp-json/wc/v3/products?per_page=100&page={page}&status=publish"
            data = await self.session.get_json(api_url)
            if not data or not isinstance(data, list):
                break
            for p in data:
                link = p.get("permalink", "")
                if link:
                    urls.append(link)
            if len(data) < 100:
                break
            page += 1
            if self.logger:
                self.logger.info(f"WC API: collected {len(urls)} URLs (page {page})")
        return urls

    async def scrape_product(self, url: str) -> Optional[Product]:
        # Try WC REST API by slug
        slug = url.rstrip("/").split("/")[-1]
        api_url = f"{self.base_url}/wp-json/wc/v3/products?slug={slug}"
        data = await self.session.get_json(api_url)
        if data and isinstance(data, list) and data:
            return self._parse_api_product(data[0], url)

        # Fallback: HTML
        html = await self.session.get(url, referer=self.base_url)
        if html:
            return self._parse_html(html, url)
        return None

    def _parse_api_product(self, p: dict, url: str) -> Product:
        product = Product()
        product.platform = "woocommerce"
        product.url = url
        product.title = p.get("name", "")
        product.description_html = p.get("description", "")
        product.short_description = BeautifulSoup(
            p.get("short_description", ""), "html.parser"
        ).get_text().strip()
        product.sku = p.get("sku", "")
        product.barcode = p.get("barcode", "")
        product.gtin = p.get("gtin", "")
        product.brand = next(
            (a["options"][0] for a in p.get("attributes", [])
             if a.get("name", "").lower() in ("brand", "make", "manufacturer") and a.get("options")),
            ""
        )
        product.product_type = p.get("type", "")
        product.tags = [t.get("name", "") for t in p.get("tags", [])]
        product.categories = [c.get("name", "") for c in p.get("categories", [])]

        # Price
        product.price = p.get("price", "")
        product.compare_at_price = p.get("regular_price", "")
        product.sale_price = p.get("sale_price", "")
        product.currency = "GBP"  # Default; override via HTML if needed

        # Stock
        product.stock_status = p.get("stock_status", "")
        product.inventory_qty = p.get("stock_quantity") or 0

        # Images
        images = p.get("images", [])
        if images:
            product.featured_image = images[0].get("src", "")
            product.images = [img.get("src", "") for img in images]
            product.image_alts = [img.get("alt", "") for img in images]

        # Dimensions / weight
        dims = p.get("dimensions", {})
        product.length = dims.get("length", "")
        product.width = dims.get("width", "")
        product.height = dims.get("height", "")
        product.weight = p.get("weight", "")

        # Attributes / specs
        for attr in p.get("attributes", []):
            name = attr.get("name", "")
            vals = attr.get("options", [])
            product.attributes[name] = ", ".join(vals)

        # Variants (variations)
        product.variant_options = [
            a["name"] for a in p.get("attributes", []) if a.get("variation")
        ]

        # SEO
        product.seo_title = p.get("name", "")
        product.seo_description = BeautifulSoup(
            p.get("short_description", ""), "html.parser"
        ).get_text()[:160]

        product.handle = p.get("slug", "")
        product.published_at = p.get("date_created", "")
        product.updated_at = p.get("date_modified", "")
        product.raw_data = p
        return product

    def _parse_html(self, html: str, url: str) -> Product:
        soup = BeautifulSoup(html, "html.parser")
        product = Product()
        product.platform = "woocommerce"
        product.url = url

        # JSON-LD
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                data = json.loads(script.string or "")
                if isinstance(data, list):
                    data = next((d for d in data if d.get("@type") == "Product"), {})
                if data.get("@type") == "Product":
                    product.title = data.get("name", "")
                    product.description_html = data.get("description", "")
                    product.sku = data.get("sku", "")
                    product.gtin = data.get("gtin13", "") or data.get("gtin", "")
                    brand = data.get("brand", {})
                    product.brand = brand.get("name", "") if isinstance(brand, dict) else ""
                    offers = data.get("offers", [{}])
                    if isinstance(offers, list):
                        offers = offers[0] if offers else {}
                    product.price = str(offers.get("price", ""))
                    product.currency = offers.get("priceCurrency", "")
                    product.stock_status = (
                        "in_stock" if "InStock" in offers.get("availability", "") else "out_of_stock"
                    )
                    imgs = data.get("image", [])
                    if isinstance(imgs, str):
                        imgs = [imgs]
                    product.images = imgs
                    if imgs:
                        product.featured_image = imgs[0]
                    break
            except Exception:
                pass

        # Title
        if not product.title:
            h1 = soup.find("h1", class_=re.compile(r"product.title|entry-title", re.I))
            if not h1:
                h1 = soup.find("h1")
            if h1:
                product.title = h1.get_text().strip()

        # Short desc
        short = soup.find(class_=re.compile(r"woocommerce-product-details__short-description|short.desc", re.I))
        if short:
            product.short_description = short.get_text().strip()[:300]

        # Price
        if not product.price:
            price_el = soup.find(class_=re.compile(r"woocommerce-Price-amount|price", re.I))
            if price_el:
                product.price = re.sub(r"[^\d.,]", "", price_el.get_text()).strip()

        # SKU
        if not product.sku:
            sku_el = soup.find(class_=re.compile(r"sku", re.I))
            if sku_el:
                product.sku = sku_el.get_text().strip()

        # Categories
        cat_els = soup.select(".posted_in a, .product_cat a")
        product.categories = [c.get_text().strip() for c in cat_els]

        # Tags
        tag_els = soup.select(".tagged_as a, .product_tag a")
        product.tags = [t.get_text().strip() for t in tag_els]

        # Attributes table
        for row in soup.select("table.woocommerce-product-attributes tr"):
            cols = row.find_all(["th", "td"])
            if len(cols) == 2:
                key = cols[0].get_text().strip()
                val = cols[1].get_text().strip()
                product.attributes[key] = val

        # Breadcrumbs
        for bc in soup.select(".woocommerce-breadcrumb a, nav.breadcrumb a"):
            product.breadcrumbs.append(bc.get_text().strip())

        # SEO
        title_tag = soup.find("title")
        product.seo_title = title_tag.get_text().strip() if title_tag else product.title
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc:
            product.seo_description = meta_desc.get("content", "")

        # Rating
        rating_el = soup.find("div", class_=re.compile(r"woocommerce-product-rating"))
        if rating_el:
            rating_val = rating_el.find(class_=re.compile(r"rating"))
            if rating_val:
                try:
                    product.rating = float(rating_val.get("style", "").split("width:")[-1].replace("%", "").strip()) / 20
                except Exception:
                    pass

        return product
