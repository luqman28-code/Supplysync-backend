"""
Generic HTML scraper - works on any custom eCommerce platform.
Uses JSON-LD, Open Graph, microdata, and heuristic selectors.
"""

import re
import json
from typing import List, Optional, Dict
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from core.models import Product, ProductVariant, ProductReview
from utils.requests import RequestSession


# Common CSS selectors for product data across platforms
SELECTORS = {
    "title": [
        "h1.product-title", "h1.product_title", "h1[itemprop='name']",
        ".product-name h1", "#product-name", "h1.entry-title", "h1",
    ],
    "price": [
        "[itemprop='price']", ".product-price", ".price", ".current-price",
        "#price", ".offer-price", "span.price", ".product__price",
        "[class*='sale-price']", "[class*='current_price']",
    ],
    "description": [
        "[itemprop='description']", "#product-description", ".product-description",
        ".product__description", ".tab-content", ".description", "#tab-description",
        "[class*='product-desc']",
    ],
    "short_description": [
        ".short-description", ".product-short-description", ".product__summary",
        ".excerpt", "#short-description",
    ],
    "sku": [
        "[itemprop='sku']", ".sku", "#sku", ".product-sku",
        "[class*='product-sku']", "[class*='sku-value']",
    ],
    "brand": [
        "[itemprop='brand']", ".brand", ".manufacturer", ".vendor",
        "[class*='product-brand']", "[class*='brand-name']",
    ],
    "images": [
        ".product-image img", ".product__image img", "#product-image img",
        ".gallery img", ".product-gallery img", "[class*='product-img'] img",
        "[itemprop='image']",
    ],
    "categories": [
        ".breadcrumb a", ".breadcrumbs a", "[class*='breadcrumb'] a",
        ".product-categories a", "[itemprop='breadcrumb'] a",
    ],
    "stock": [
        "[itemprop='availability']", ".stock", ".availability",
        ".product-availability", "[class*='in-stock']", "[class*='out-of-stock']",
    ],
}


class GenericScraper:
    def __init__(self, base_url: str, session: RequestSession, logger=None):
        self.base_url = base_url.rstrip("/")
        self.session = session
        self.logger = logger

    async def scrape_product(self, url: str) -> Optional[Product]:
        html = await self.session.get(url, referer=self.base_url)
        if not html:
            return None
        return self._parse(html, url)

    def _parse(self, html: str, url: str) -> Product:
        soup = BeautifulSoup(html, "html.parser")
        product = Product()
        product.platform = "custom"
        product.url = url
        product.handle = url.rstrip("/").split("/")[-1]
        product.canonical_url = url

        # --- 1. JSON-LD (most reliable) ---
        self._extract_json_ld(soup, product)

        # --- 2. Open Graph ---
        self._extract_og(soup, product)

        # --- 3. Microdata ---
        self._extract_microdata(soup, product)

        # --- 4. Heuristic CSS selectors ---
        self._extract_heuristic(soup, product, url)

        # --- 5. SEO tags ---
        self._extract_seo(soup, product)

        # --- 6. Reviews ---
        self._extract_reviews(soup, product)

        # --- 7. Related products ---
        self._extract_related(soup, product, url)

        # --- 8. Downloads / PDFs ---
        for a in soup.find_all("a", href=re.compile(r"\.pdf$", re.I)):
            href = a.get("href", "")
            if href:
                product.downloads.append(urljoin(url, href))

        # --- 9. Videos ---
        for v in soup.find_all(["video", "iframe"]):
            src = v.get("src", "") or v.get("data-src", "")
            if src and ("youtube" in src or "vimeo" in src or src.endswith((".mp4", ".webm"))):
                product.videos.append(src)

        return product

    def _extract_json_ld(self, soup: BeautifulSoup, product: Product):
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                raw = script.string or ""
                data = json.loads(raw)
                # Handle @graph
                if isinstance(data, dict) and "@graph" in data:
                    items = data["@graph"]
                elif isinstance(data, list):
                    items = data
                else:
                    items = [data]

                for item in items:
                    if not isinstance(item, dict):
                        continue
                    t = item.get("@type", "")
                    if t != "Product" and "Product" not in (t if isinstance(t, list) else [t]):
                        continue

                    if not product.title:
                        product.title = item.get("name", "")
                    if not product.description_html:
                        product.description_html = item.get("description", "")
                    if not product.sku:
                        product.sku = item.get("sku", "")
                    if not product.gtin:
                        product.gtin = (item.get("gtin13") or item.get("gtin14")
                                        or item.get("gtin8") or item.get("gtin") or "")
                    if not product.mpn:
                        product.mpn = item.get("mpn", "")

                    brand = item.get("brand", {})
                    if isinstance(brand, dict) and not product.brand:
                        product.brand = brand.get("name", "")
                    elif isinstance(brand, str) and not product.brand:
                        product.brand = brand

                    # Images
                    imgs = item.get("image", [])
                    if isinstance(imgs, str):
                        imgs = [imgs]
                    elif isinstance(imgs, dict):
                        imgs = [imgs.get("url", "")]
                    if imgs and not product.images:
                        product.images = [i for i in imgs if i]
                        product.featured_image = product.images[0] if product.images else ""

                    # Offers
                    offers = item.get("offers", {})
                    if isinstance(offers, list):
                        offers = offers[0] if offers else {}
                    if isinstance(offers, dict):
                        if not product.price:
                            product.price = str(offers.get("price", ""))
                        if not product.currency:
                            product.currency = offers.get("priceCurrency", "")
                        avail = offers.get("availability", "")
                        if not product.stock_status:
                            product.stock_status = "in_stock" if "InStock" in avail else "out_of_stock"
                        if not product.sku:
                            product.sku = offers.get("sku", "")

                    # Aggregate rating
                    agg = item.get("aggregateRating", {})
                    if isinstance(agg, dict) and not product.rating:
                        try:
                            product.rating = float(agg.get("ratingValue", 0))
                            product.review_count = int(agg.get("reviewCount", 0))
                        except Exception:
                            pass

                    # Reviews
                    for rev in item.get("review", []):
                        r = ProductReview()
                        r.author = rev.get("author", {}).get("name", "") if isinstance(rev.get("author"), dict) else rev.get("author", "")
                        r.body = rev.get("reviewBody", "")
                        r.title = rev.get("name", "")
                        rating_val = rev.get("reviewRating", {})
                        if isinstance(rating_val, dict):
                            try:
                                r.rating = float(rating_val.get("ratingValue", 0))
                            except Exception:
                                pass
                        r.date = rev.get("datePublished", "")
                        product.reviews.append(r)
                    break
            except Exception:
                pass

    def _extract_og(self, soup: BeautifulSoup, product: Product):
        og = {}
        for meta in soup.find_all("meta", property=re.compile(r"^og:", re.I)):
            prop = meta.get("property", "").replace("og:", "")
            content = meta.get("content", "")
            og[prop] = content

        if not product.title and og.get("title"):
            product.title = og["title"]
        if not product.description_html and og.get("description"):
            product.description_html = og["description"]
        if not product.featured_image and og.get("image"):
            product.featured_image = og["image"]
            if og["image"] not in product.images:
                product.images.insert(0, og["image"])
        if not product.currency:
            product.currency = og.get("price:currency", "")
        if not product.price:
            product.price = og.get("price:amount", "")

    def _extract_microdata(self, soup: BeautifulSoup, product: Product):
        item_scope = soup.find(attrs={"itemscope": True, "itemtype": re.compile(r"schema\.org/Product", re.I)})
        if not item_scope:
            return

        def get_prop(name):
            el = item_scope.find(attrs={"itemprop": name})
            if el:
                return el.get("content") or el.get("src") or el.get_text().strip()
            return ""

        if not product.title:
            product.title = get_prop("name")
        if not product.description_html:
            product.description_html = get_prop("description")
        if not product.sku:
            product.sku = get_prop("sku")
        if not product.brand:
            product.brand = get_prop("brand")
        if not product.price:
            product.price = get_prop("price")
        if not product.currency:
            product.currency = get_prop("priceCurrency")

    def _extract_heuristic(self, soup: BeautifulSoup, product: Product, url: str):
        # Title
        if not product.title:
            for sel in SELECTORS["title"]:
                el = soup.select_one(sel)
                if el:
                    product.title = el.get_text().strip()
                    break

        # Price
        if not product.price:
            for sel in SELECTORS["price"]:
                el = soup.select_one(sel)
                if el:
                    txt = el.get_text().strip()
                    nums = re.findall(r"[\d,]+\.?\d*", txt)
                    if nums:
                        product.price = nums[0].replace(",", "")
                        # Try to detect currency symbol
                        if "£" in txt:
                            product.currency = "GBP"
                        elif "$" in txt:
                            product.currency = "USD"
                        elif "€" in txt:
                            product.currency = "EUR"
                        break

        # Description
        if not product.description_html:
            for sel in SELECTORS["description"]:
                el = soup.select_one(sel)
                if el:
                    product.description_html = str(el)
                    product.short_description = el.get_text().strip()[:300]
                    break

        # Short description
        if not product.short_description:
            for sel in SELECTORS["short_description"]:
                el = soup.select_one(sel)
                if el:
                    product.short_description = el.get_text().strip()[:300]
                    break

        # SKU
        if not product.sku:
            for sel in SELECTORS["sku"]:
                el = soup.select_one(sel)
                if el:
                    txt = el.get_text().strip()
                    sku = re.sub(r"^(sku|model|ref|mpn|part)[\s:#]*", "", txt, flags=re.I).strip()
                    if sku:
                        product.sku = sku
                        break

        # Brand
        if not product.brand:
            for sel in SELECTORS["brand"]:
                el = soup.select_one(sel)
                if el:
                    product.brand = el.get_text().strip()
                    break

        # Images
        if not product.images:
            seen = set()
            for sel in SELECTORS["images"]:
                for img in soup.select(sel):
                    src = img.get("data-src") or img.get("data-lazy-src") or img.get("src", "")
                    if src and not src.startswith("data:") and src not in seen:
                        full = urljoin(url, src)
                        # Skip tiny placeholder images
                        if "placeholder" not in full.lower() and "blank" not in full.lower():
                            product.images.append(full)
                            product.image_alts.append(img.get("alt", ""))
                            seen.add(src)
            if product.images:
                product.featured_image = product.images[0]

        # Also check high-res data attributes
        for img in soup.find_all("img", attrs={"data-large_image": True}):
            src = img["data-large_image"]
            if src and src not in product.images:
                product.images.append(urljoin(url, src))

        # Stock
        if not product.stock_status:
            for sel in SELECTORS["stock"]:
                el = soup.select_one(sel)
                if el:
                    txt = el.get("content", "") or el.get_text().strip()
                    if re.search(r"in.?stock|available|in stock", txt, re.I):
                        product.stock_status = "in_stock"
                    elif re.search(r"out.?of.?stock|unavailable|sold.?out", txt, re.I):
                        product.stock_status = "out_of_stock"
                    break

        # Categories / breadcrumbs
        if not product.categories:
            crumbs = []
            for sel in SELECTORS["categories"]:
                els = soup.select(sel)
                if els:
                    crumbs = [e.get_text().strip() for e in els if e.get_text().strip()]
                    break
            if crumbs:
                product.breadcrumbs = crumbs
                product.categories = crumbs[1:-1] if len(crumbs) > 2 else crumbs

        # Weight / dimensions from spec tables
        for table in soup.find_all("table"):
            for row in table.find_all("tr"):
                cols = row.find_all(["th", "td"])
                if len(cols) >= 2:
                    key = cols[0].get_text().strip().lower()
                    val = cols[1].get_text().strip()
                    if "weight" in key:
                        product.weight = val
                    elif "length" in key:
                        product.length = val
                    elif "width" in key or "breadth" in key:
                        product.width = val
                    elif "height" in key or "depth" in key:
                        product.height = val
                    else:
                        product.specifications[cols[0].get_text().strip()] = val

        # Also check definition lists (dl/dt/dd)
        for dl in soup.find_all("dl"):
            dts = dl.find_all("dt")
            dds = dl.find_all("dd")
            for dt, dd in zip(dts, dds):
                key = dt.get_text().strip()
                val = dd.get_text().strip()
                if key:
                    product.attributes[key] = val

        # Variants from select dropdowns
        variant_options = []
        for select in soup.find_all("select"):
            name = select.get("name", "") or select.get("id", "")
            if not name:
                continue
            opts = [o.get_text().strip() for o in select.find_all("option") if o.get_text().strip()]
            if opts and name.lower() not in ("qty", "quantity", "country", "state", "region"):
                variant_options.append({"name": name, "values": opts})

        if variant_options:
            product.variant_options = [v["name"] for v in variant_options]
            # Build simple variant combinations (first option only for brevity)
            for opt in variant_options[:3]:
                for val in opt["values"]:
                    v = ProductVariant()
                    v.option1_name = opt["name"]
                    v.option1_value = val
                    v.price = product.price
                    product.variants.append(v)

    def _extract_seo(self, soup: BeautifulSoup, product: Product):
        title_tag = soup.find("title")
        if title_tag and not product.seo_title:
            product.seo_title = title_tag.get_text().strip()
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc and not product.seo_description:
            product.seo_description = meta_desc.get("content", "")
        canonical = soup.find("link", rel="canonical")
        if canonical:
            product.canonical_url = canonical.get("href", "")
        # Keywords as tags fallback
        meta_kw = soup.find("meta", attrs={"name": "keywords"})
        if meta_kw and not product.tags:
            kws = meta_kw.get("content", "")
            product.tags = [k.strip() for k in kws.split(",") if k.strip()]

    def _extract_reviews(self, soup: BeautifulSoup, product: Product):
        # Common review containers
        for rev_el in soup.select(".review, .customer-review, [class*='review-item']"):
            r = ProductReview()
            author_el = rev_el.select_one(".reviewer, .author, [class*='reviewer-name']")
            if author_el:
                r.author = author_el.get_text().strip()
            body_el = rev_el.select_one(".review-body, .description, [class*='review-text'], p")
            if body_el:
                r.body = body_el.get_text().strip()
            title_el = rev_el.select_one(".review-title, h3, h4")
            if title_el:
                r.title = title_el.get_text().strip()
            date_el = rev_el.select_one("time, .date, [class*='review-date']")
            if date_el:
                r.date = date_el.get("datetime", "") or date_el.get_text().strip()
            # Rating from star elements
            stars = rev_el.select("[class*='star'], [class*='rating']")
            if stars:
                filled = sum(1 for s in stars if "filled" in s.get("class", []) or "active" in s.get("class", []))
                if filled:
                    r.rating = float(filled)
            if r.author or r.body:
                product.reviews.append(r)

    def _extract_related(self, soup: BeautifulSoup, product: Product, url: str):
        base_domain = urlparse(url).netloc
        for section in soup.select("[class*='related'], [class*='upsell'], [class*='cross-sell']"):
            for a in section.find_all("a", href=True):
                href = a["href"]
                full = urljoin(url, href)
                if urlparse(full).netloc == base_domain and full not in product.related_products:
                    product.related_products.append(full)
