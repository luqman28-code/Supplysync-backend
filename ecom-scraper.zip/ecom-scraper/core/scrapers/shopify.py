"""
Shopify scraper - uses the /products.json API endpoint + HTML fallback.
"""

import re
import json
from typing import List, Optional
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from core.models import Product, ProductVariant, ProductReview
from utils.requests import RequestSession


class ShopifyScraper:
    def __init__(self, base_url: str, session: RequestSession, logger=None):
        self.base_url = base_url.rstrip("/")
        self.session = session
        self.logger = logger

    async def get_product_urls(self) -> List[str]:
        """Collect all product URLs via /products.json paginated API."""
        urls = []
        page = 1
        while True:
            api_url = f"{self.base_url}/products.json?limit=250&page={page}"
            data = await self.session.get_json(api_url)
            if not data or not data.get("products"):
                break
            for p in data["products"]:
                handle = p.get("handle", "")
                if handle:
                    urls.append(f"{self.base_url}/products/{handle}")
            if len(data["products"]) < 250:
                break
            page += 1
            if self.logger:
                self.logger.info(f"Collected {len(urls)} Shopify product URLs (page {page})")
        return urls

    async def scrape_product(self, url: str) -> Optional[Product]:
        """Scrape a single Shopify product via .json endpoint."""
        json_url = url.split("?")[0].rstrip("/") + ".json"
        data = await self.session.get_json(json_url)

        if data and "product" in data:
            return self._parse_product_json(data["product"], url)

        # Fallback: parse HTML
        html = await self.session.get(url)
        if html:
            return self._parse_product_html(html, url)
        return None

    def _parse_product_json(self, p: dict, url: str) -> Product:
        product = Product()
        product.platform = "shopify"
        product.url = url
        product.handle = p.get("handle", "")
        product.title = p.get("title", "")
        product.description_html = p.get("body_html", "")
        product.short_description = BeautifulSoup(
            p.get("body_html", ""), "html.parser"
        ).get_text()[:300]
        product.vendor = p.get("vendor", "")
        product.brand = p.get("vendor", "")
        product.product_type = p.get("product_type", "")
        product.tags = [t.strip() for t in p.get("tags", "").split(",") if t.strip()]
        product.published_at = p.get("published_at", "")
        product.updated_at = p.get("updated_at", "")

        # Images
        images = p.get("images", [])
        if images:
            product.featured_image = images[0].get("src", "")
            product.images = [img.get("src", "") for img in images]
            product.image_alts = [img.get("alt", "") or "" for img in images]

        # Options
        options = p.get("options", [])
        product.variant_options = [o.get("name", "") for o in options]

        # Variants
        for v in p.get("variants", []):
            variant = ProductVariant()
            variant.sku = v.get("sku", "")
            variant.barcode = v.get("barcode", "") or ""
            variant.title = v.get("title", "")
            variant.price = v.get("price", "")
            variant.compare_at_price = v.get("compare_at_price", "") or ""
            variant.stock_status = "in_stock" if v.get("available") else "out_of_stock"
            variant.inventory_qty = v.get("inventory_quantity", 0) or 0
            variant.weight = str(v.get("weight", ""))
            variant.weight_unit = v.get("weight_unit", "kg")
            variant.available = v.get("available", True)

            # Map option values
            if len(options) > 0:
                variant.option1_name = options[0].get("name", "")
                variant.option1_value = v.get("option1", "")
            if len(options) > 1:
                variant.option2_name = options[1].get("name", "")
                variant.option2_value = v.get("option2", "")
            if len(options) > 2:
                variant.option3_name = options[2].get("name", "")
                variant.option3_value = v.get("option3", "")

            # Variant image
            img_id = v.get("image_id")
            if img_id:
                for img in images:
                    if img.get("id") == img_id:
                        variant.image_url = img.get("src", "")
                        break

            product.variants.append(variant)

        # Price from first variant
        if product.variants:
            product.price = product.variants[0].price
            product.compare_at_price = product.variants[0].compare_at_price
            product.sku = product.variants[0].sku
            product.barcode = product.variants[0].barcode
            all_avail = any(v.available for v in product.variants)
            product.stock_status = "in_stock" if all_avail else "out_of_stock"

        product.raw_data = p
        return product

    def _parse_product_html(self, html: str, url: str) -> Product:
        """Fallback HTML parser for Shopify pages."""
        soup = BeautifulSoup(html, "html.parser")
        product = Product()
        product.platform = "shopify"
        product.url = url

        # Try JSON-LD
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                data = json.loads(script.string or "")
                if isinstance(data, list):
                    data = next((d for d in data if d.get("@type") == "Product"), {})
                if data.get("@type") == "Product":
                    product.title = data.get("name", "")
                    product.description_html = data.get("description", "")
                    product.brand = data.get("brand", {}).get("name", "") if isinstance(data.get("brand"), dict) else ""
                    product.sku = data.get("sku", "")
                    product.gtin = data.get("gtin13", "") or data.get("gtin", "")
                    product.seo_description = data.get("description", "")[:160]
                    offers = data.get("offers", {})
                    if isinstance(offers, list):
                        offers = offers[0] if offers else {}
                    product.price = str(offers.get("price", ""))
                    product.currency = offers.get("priceCurrency", "")
                    product.stock_status = "in_stock" if "InStock" in offers.get("availability", "") else "out_of_stock"
                    imgs = data.get("image", [])
                    if isinstance(imgs, str):
                        imgs = [imgs]
                    product.images = imgs
                    if imgs:
                        product.featured_image = imgs[0]
                    break
            except Exception:
                pass

        # SEO
        title_tag = soup.find("title")
        product.seo_title = title_tag.get_text().strip() if title_tag else ""
        meta_desc = soup.find("meta", attrs={"name": "description"})
        if meta_desc:
            product.seo_description = meta_desc.get("content", "")

        # Breadcrumbs
        for bc in soup.select("[class*='breadcrumb'] a, nav[aria-label*='breadcrumb'] a"):
            product.breadcrumbs.append(bc.get_text().strip())

        # Title fallback
        if not product.title:
            h1 = soup.find("h1")
            if h1:
                product.title = h1.get_text().strip()

        return product
