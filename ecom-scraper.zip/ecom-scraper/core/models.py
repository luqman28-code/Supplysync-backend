"""
Product data model - unified schema for all platforms.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class ProductVariant:
    sku: str = ""
    barcode: str = ""
    title: str = ""
    option1_name: str = ""
    option1_value: str = ""
    option2_name: str = ""
    option2_value: str = ""
    option3_name: str = ""
    option3_value: str = ""
    price: str = ""
    compare_at_price: str = ""
    stock_status: str = ""
    inventory_qty: int = 0
    weight: str = ""
    weight_unit: str = "kg"
    image_url: str = ""
    available: bool = True


@dataclass
class ProductReview:
    author: str = ""
    rating: float = 0.0
    title: str = ""
    body: str = ""
    date: str = ""
    verified: bool = False


@dataclass
class Product:
    # Identifiers
    url: str = ""
    handle: str = ""
    sku: str = ""
    barcode: str = ""
    gtin: str = ""
    ean: str = ""
    upc: str = ""
    mpn: str = ""

    # Core
    title: str = ""
    description_html: str = ""
    short_description: str = ""
    brand: str = ""
    vendor: str = ""
    product_type: str = ""
    platform: str = ""

    # Pricing
    price: str = ""
    compare_at_price: str = ""
    sale_price: str = ""
    currency: str = ""

    # Taxonomy
    categories: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    collections: List[str] = field(default_factory=list)
    breadcrumbs: List[str] = field(default_factory=list)

    # Media
    featured_image: str = ""
    images: List[str] = field(default_factory=list)
    image_alts: List[str] = field(default_factory=list)
    videos: List[str] = field(default_factory=list)
    downloads: List[str] = field(default_factory=list)

    # Inventory
    stock_status: str = ""
    inventory_qty: int = 0
    tracked: bool = False

    # Physical
    weight: str = ""
    weight_unit: str = ""
    length: str = ""
    width: str = ""
    height: str = ""
    dimension_unit: str = ""

    # Attributes / Specs
    attributes: Dict[str, str] = field(default_factory=dict)
    specifications: Dict[str, str] = field(default_factory=dict)

    # Variants
    variant_options: List[str] = field(default_factory=list)  # option names
    variants: List[ProductVariant] = field(default_factory=list)

    # SEO
    seo_title: str = ""
    seo_description: str = ""
    canonical_url: str = ""

    # Shipping
    shipping_info: str = ""
    requires_shipping: bool = True

    # Reviews
    rating: float = 0.0
    review_count: int = 0
    reviews: List[ProductReview] = field(default_factory=list)

    # Related
    related_products: List[str] = field(default_factory=list)

    # Meta
    published_at: str = ""
    updated_at: str = ""
    raw_data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = {}
        for k, v in self.__dict__.items():
            if k == "variants":
                d[k] = [vars(var) for var in v]
            elif k == "reviews":
                d[k] = [vars(r) for r in v]
            else:
                d[k] = v
        return d
