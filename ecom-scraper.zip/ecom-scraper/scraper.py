#!/usr/bin/env python3
"""
Enterprise eCommerce Scraper
Supports: Shopify, WooCommerce, Magento, custom PHP stores, and more.
"""

import asyncio
import argparse
import logging
import sys
from pathlib import Path
from core.crawler import Crawler
from core.platform_detector import PlatformDetector
from exporters.exporter import Exporter
from utils.logger import setup_logger

def parse_args():
    parser = argparse.ArgumentParser(
        description="Enterprise eCommerce Product Scraper",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scraper.py --url https://example.com
  python scraper.py --url https://example.com --format shopify_csv --proxy http://proxy:8080
  python scraper.py --url https://example.com --format all --max-products 500 --workers 5
        """
    )
    parser.add_argument("--url", required=True, help="Target website URL")
    parser.add_argument("--format", default="all",
                        choices=["json", "csv", "excel", "shopify_csv", "all"],
                        help="Export format (default: all)")
    parser.add_argument("--output", default="output", help="Output directory")
    parser.add_argument("--max-products", type=int, default=0, help="Max products (0 = unlimited)")
    parser.add_argument("--workers", type=int, default=3, help="Concurrent workers")
    parser.add_argument("--delay", type=float, default=1.0, help="Delay between requests (seconds)")
    parser.add_argument("--proxy", help="Proxy URL (e.g. http://user:pass@host:port)")
    parser.add_argument("--proxy-list", help="Path to file with proxy list (one per line)")
    parser.add_argument("--no-images", action="store_true", help="Skip image URL extraction")
    parser.add_argument("--no-reviews", action="store_true", help="Skip review extraction")
    parser.add_argument("--platform", help="Force platform (shopify/woocommerce/magento/custom)")
    parser.add_argument("--sitemap", help="Sitemap URL to use instead of crawling")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    return parser.parse_args()


async def main():
    args = parse_args()
    logger = setup_logger(args.log_level, args.output)
    logger.info("=" * 60)
    logger.info("Enterprise eCommerce Scraper Starting")
    logger.info(f"Target: {args.url}")
    logger.info("=" * 60)

    # Detect platform
    detector = PlatformDetector(args.url)
    if args.platform:
        platform = args.platform
        logger.info(f"Platform forced: {platform}")
    else:
        platform = await detector.detect()
        logger.info(f"Platform detected: {platform}")

    # Load proxies
    proxies = []
    if args.proxy_list:
        with open(args.proxy_list) as f:
            proxies = [line.strip() for line in f if line.strip()]
        logger.info(f"Loaded {len(proxies)} proxies")
    elif args.proxy:
        proxies = [args.proxy]

    # Run crawler
    crawler = Crawler(
        base_url=args.url,
        platform=platform,
        workers=args.workers,
        delay=args.delay,
        proxies=proxies,
        max_products=args.max_products,
        skip_images=args.no_images,
        skip_reviews=args.no_reviews,
        sitemap_url=args.sitemap,
        logger=logger,
    )

    products = await crawler.run()
    logger.info(f"Scraped {len(products)} products total")

    if not products:
        logger.warning("No products found. Check URL or try --platform flag.")
        sys.exit(1)

    # Export
    exporter = Exporter(products, args.output, logger)
    if args.format == "all":
        exporter.to_json()
        exporter.to_csv()
        exporter.to_excel()
        exporter.to_shopify_csv()
    elif args.format == "json":
        exporter.to_json()
    elif args.format == "csv":
        exporter.to_csv()
    elif args.format == "excel":
        exporter.to_excel()
    elif args.format == "shopify_csv":
        exporter.to_shopify_csv()

    logger.info("Done. Outputs saved to: " + args.output)


if __name__ == "__main__":
    asyncio.run(main())
