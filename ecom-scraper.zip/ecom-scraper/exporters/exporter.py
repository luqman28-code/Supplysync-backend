"""
Exporter - outputs scraped products to JSON, CSV, Excel, and Shopify-compatible CSV.
"""

import json
import csv
import os
from datetime import datetime
from typing import List
from pathlib import Path
from core.models import Product


class Exporter:
    def __init__(self, products: List[Product], output_dir: str, logger=None):
        self.products = products
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logger
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    def log(self, msg):
        if self.logger:
            self.logger.info(msg)

    def _path(self, suffix: str) -> Path:
        return self.output_dir / f"products_{self.timestamp}.{suffix}"

    # ── JSON ──────────────────────────────────────────────────────────────────
    def to_json(self):
        path = self._path("json")
        data = [p.to_dict() for p in self.products]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        self.log(f"JSON exported: {path} ({len(self.products)} products)")

    # ── CSV (flat) ─────────────────────────────────────────────────────────────
    def to_csv(self):
        path = self._path("csv")
        rows = self._flatten_products()
        if not rows:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        self.log(f"CSV exported: {path}")

    # ── Excel ─────────────────────────────────────────────────────────────────
    def to_excel(self):
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
        except ImportError:
            self.log("openpyxl not installed — skipping Excel export")
            return

        path = self._path("xlsx")
        wb = openpyxl.Workbook()

        # Products sheet
        ws = wb.active
        ws.title = "Products"
        rows = self._flatten_products()
        if rows:
            headers = list(rows[0].keys())
            header_fill = PatternFill("solid", fgColor="1F4E79")
            header_font = Font(color="FFFFFF", bold=True)
            for col, h in enumerate(headers, 1):
                cell = ws.cell(row=1, column=col, value=h)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center")
            for row_idx, row in enumerate(rows, 2):
                for col_idx, val in enumerate(row.values(), 1):
                    ws.cell(row=row_idx, column=col_idx, value=str(val) if val is not None else "")
            # Auto-width
            for col in ws.columns:
                max_len = max((len(str(cell.value or "")) for cell in col), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 60)

        # Variants sheet
        ws2 = wb.create_sheet("Variants")
        variant_rows = self._flatten_variants()
        if variant_rows:
            headers2 = list(variant_rows[0].keys())
            for col, h in enumerate(headers2, 1):
                cell = ws2.cell(row=1, column=col, value=h)
                cell.font = Font(bold=True)
            for row_idx, row in enumerate(variant_rows, 2):
                for col_idx, val in enumerate(row.values(), 1):
                    ws2.cell(row=row_idx, column=col_idx, value=str(val) if val is not None else "")

        wb.save(path)
        self.log(f"Excel exported: {path}")

    # ── Shopify CSV ───────────────────────────────────────────────────────────
    def to_shopify_csv(self):
        """
        Generates a Shopify-compatible product import CSV.
        https://help.shopify.com/en/manual/products/import-export/using-csv
        """
        path = self.output_dir / f"products_{self.timestamp}_shopify.csv"
        shopify_headers = [
            "Handle", "Title", "Body (HTML)", "Vendor", "Product Category",
            "Type", "Tags", "Published", "Option1 Name", "Option1 Value",
            "Option2 Name", "Option2 Value", "Option3 Name", "Option3 Value",
            "Variant SKU", "Variant Grams", "Variant Inventory Tracker",
            "Variant Inventory Qty", "Variant Inventory Policy",
            "Variant Fulfillment Service", "Variant Price",
            "Variant Compare At Price", "Variant Requires Shipping",
            "Variant Taxable", "Variant Barcode", "Image Src", "Image Position",
            "Image Alt Text", "Gift Card", "SEO Title", "SEO Description",
            "Google Shopping / Google Product Category", "Google Shopping / Gender",
            "Google Shopping / Age Group", "Google Shopping / MPN",
            "Google Shopping / AdWords Grouping", "Google Shopping / AdWords Labels",
            "Google Shopping / Condition", "Google Shopping / Custom Product",
            "Google Shopping / Custom Label 0", "Variant Image",
            "Variant Weight Unit", "Variant Tax Code", "Cost per item",
            "Included / United Kingdom", "Status",
        ]

        rows = []
        for product in self.products:
            handle = product.handle or self._to_handle(product.title)
            tags = ", ".join(product.tags)
            is_first = True

            variants = product.variants or [None]
            images = product.images or [product.featured_image]

            for v_idx, variant in enumerate(variants):
                # For each variant, we write a row; images go on first rows
                image_src = images[v_idx] if v_idx < len(images) else ""
                image_alt = product.image_alts[v_idx] if v_idx < len(product.image_alts) else ""
                image_pos = v_idx + 1 if v_idx < len(images) else ""

                row = {
                    "Handle": handle,
                    "Title": product.title if is_first else "",
                    "Body (HTML)": product.description_html if is_first else "",
                    "Vendor": product.vendor or product.brand,
                    "Product Category": product.categories[0] if product.categories else "",
                    "Type": product.product_type,
                    "Tags": tags if is_first else "",
                    "Published": "TRUE",
                    "Option1 Name": variant.option1_name if variant else (product.variant_options[0] if product.variant_options else "Title"),
                    "Option1 Value": variant.option1_value if variant else "Default Title",
                    "Option2 Name": variant.option2_name if variant else "",
                    "Option2 Value": variant.option2_value if variant else "",
                    "Option3 Name": variant.option3_name if variant else "",
                    "Option3 Value": variant.option3_value if variant else "",
                    "Variant SKU": variant.sku if variant else product.sku,
                    "Variant Grams": self._weight_to_grams(
                        (variant.weight if variant else None) or product.weight,
                        (variant.weight_unit if variant else None) or product.weight_unit
                    ),
                    "Variant Inventory Tracker": "shopify",
                    "Variant Inventory Qty": variant.inventory_qty if variant else product.inventory_qty,
                    "Variant Inventory Policy": "deny",
                    "Variant Fulfillment Service": "manual",
                    "Variant Price": variant.price if variant else product.price,
                    "Variant Compare At Price": variant.compare_at_price if variant else product.compare_at_price,
                    "Variant Requires Shipping": "TRUE",
                    "Variant Taxable": "TRUE",
                    "Variant Barcode": variant.barcode if variant else product.barcode or product.gtin or product.ean,
                    "Image Src": image_src,
                    "Image Position": image_pos,
                    "Image Alt Text": image_alt,
                    "Gift Card": "FALSE",
                    "SEO Title": product.seo_title if is_first else "",
                    "SEO Description": product.seo_description if is_first else "",
                    "Google Shopping / MPN": product.mpn,
                    "Google Shopping / Condition": "new",
                    "Variant Image": variant.image_url if variant else "",
                    "Variant Weight Unit": (variant.weight_unit if variant else product.weight_unit) or "kg",
                    "Status": "draft",
                    "Included / United Kingdom": "TRUE",
                    "Cost per item": "",
                    "Variant Tax Code": "",
                    "Google Shopping / Google Product Category": "",
                    "Google Shopping / Gender": "",
                    "Google Shopping / Age Group": "",
                    "Google Shopping / AdWords Grouping": "",
                    "Google Shopping / AdWords Labels": "",
                    "Google Shopping / Custom Product": "",
                    "Google Shopping / Custom Label 0": "",
                }
                rows.append(row)
                is_first = False

            # Additional images (beyond variant count)
            for img_idx in range(len(variants), len(images)):
                rows.append({
                    "Handle": handle,
                    "Title": "",
                    "Body (HTML)": "",
                    "Image Src": images[img_idx],
                    "Image Position": img_idx + 1,
                    "Image Alt Text": product.image_alts[img_idx] if img_idx < len(product.image_alts) else "",
                    **{k: "" for k in shopify_headers if k not in ("Handle", "Title", "Body (HTML)", "Image Src", "Image Position", "Image Alt Text")},
                })

        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=shopify_headers, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)

        self.log(f"Shopify CSV exported: {path} ({len(rows)} rows for {len(self.products)} products)")

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _flatten_products(self) -> List[dict]:
        rows = []
        for p in self.products:
            row = {
                "URL": p.url,
                "Handle": p.handle,
                "Title": p.title,
                "Brand": p.brand or p.vendor,
                "Product Type": p.product_type,
                "SKU": p.sku,
                "Barcode": p.barcode or p.gtin or p.ean,
                "Price": p.price,
                "Compare At Price": p.compare_at_price,
                "Sale Price": p.sale_price,
                "Currency": p.currency,
                "Stock Status": p.stock_status,
                "Inventory Qty": p.inventory_qty,
                "Categories": " > ".join(p.categories),
                "Tags": ", ".join(p.tags),
                "Collections": ", ".join(p.collections),
                "Weight": p.weight,
                "Weight Unit": p.weight_unit,
                "Length": p.length,
                "Width": p.width,
                "Height": p.height,
                "Featured Image": p.featured_image,
                "Images": " | ".join(p.images),
                "Videos": " | ".join(p.videos),
                "Downloads": " | ".join(p.downloads),
                "Rating": p.rating,
                "Review Count": p.review_count,
                "SEO Title": p.seo_title,
                "SEO Description": p.seo_description,
                "Canonical URL": p.canonical_url,
                "Breadcrumbs": " > ".join(p.breadcrumbs),
                "Description HTML": p.description_html,
                "Short Description": p.short_description,
                "Attributes": json.dumps(p.attributes, ensure_ascii=False),
                "Specifications": json.dumps(p.specifications, ensure_ascii=False),
                "Variant Count": len(p.variants),
                "Platform": p.platform,
                "Published At": p.published_at,
                "Updated At": p.updated_at,
            }
            rows.append(row)
        return rows

    def _flatten_variants(self) -> List[dict]:
        rows = []
        for p in self.products:
            for v in p.variants:
                rows.append({
                    "Product URL": p.url,
                    "Product Title": p.title,
                    "Product SKU": p.sku,
                    "Variant Title": v.title,
                    "Variant SKU": v.sku,
                    "Barcode": v.barcode,
                    "Option1 Name": v.option1_name,
                    "Option1 Value": v.option1_value,
                    "Option2 Name": v.option2_name,
                    "Option2 Value": v.option2_value,
                    "Option3 Name": v.option3_name,
                    "Option3 Value": v.option3_value,
                    "Price": v.price,
                    "Compare At Price": v.compare_at_price,
                    "Stock Status": v.stock_status,
                    "Inventory Qty": v.inventory_qty,
                    "Weight": v.weight,
                    "Weight Unit": v.weight_unit,
                    "Image URL": v.image_url,
                    "Available": v.available,
                })
        return rows

    @staticmethod
    def _to_handle(title: str) -> str:
        import re
        h = title.lower()
        h = re.sub(r"[^a-z0-9\s-]", "", h)
        h = re.sub(r"\s+", "-", h.strip())
        return h[:255]

    @staticmethod
    def _weight_to_grams(weight: str, unit: str) -> str:
        if not weight:
            return ""
        try:
            w = float(str(weight).replace(",", "."))
            unit = (unit or "kg").lower()
            if unit == "kg":
                return str(int(w * 1000))
            elif unit == "lb" or unit == "lbs":
                return str(int(w * 453.592))
            elif unit == "oz":
                return str(int(w * 28.3495))
            elif unit in ("g", "grams"):
                return str(int(w))
        except Exception:
            return ""
        return ""
